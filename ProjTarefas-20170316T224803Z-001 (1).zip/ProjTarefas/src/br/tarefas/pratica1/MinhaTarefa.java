package br.tarefas.pratica1;

public class MinhaTarefa {
	private String nome;
	
	public MinhaTarefa (String nome ){
		this.nome= nome;		
	}
	
	public void executar(){
		
		
			try {
				for(int i=0 ; i<=5;i++){
			System.out.println(nome + ": " + i);		
				}
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println("FOI FINALIZADO!");
		}
	}

