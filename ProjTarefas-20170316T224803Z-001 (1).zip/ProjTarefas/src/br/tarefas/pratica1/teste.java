package br.tarefas.pratica1;

public class teste {

	public static void main(String[] args) {
		MinhaTarefa tarefa1 = new MinhaTarefa("Tarefa #1");
		tarefa1.executar();
		
		MinhaTarefa tarefa2 = new MinhaTarefa("Tarefa #2");
		tarefa2.executar();

	}

}
