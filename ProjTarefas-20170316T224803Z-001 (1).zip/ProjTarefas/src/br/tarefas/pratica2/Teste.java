package br.tarefas.pratica2;

public class Teste {

	public static void main(String[] args) {
		MinhaTarefa tarefa1= new MinhaTarefa("Tarefa #1",500);
		tarefa1.start();
		
		MinhaTarefa tarefa2= new MinhaTarefa("Tarefa #2",800);
		tarefa2.start();
	}

}
