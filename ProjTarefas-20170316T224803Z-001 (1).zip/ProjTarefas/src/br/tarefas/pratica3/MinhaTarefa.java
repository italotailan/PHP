package br.tarefas.pratica3;

public class MinhaTarefa implements Runnable {
	
	private String nome;
	private int tempo;
	
	public MinhaTarefa(String nome,int tempo){
		this.nome=nome;
		this.tempo=tempo;
	}
	
	public void run(){
		try{
			for(int i=0; i <= 5 ; i++){
				System.out.println(nome +" : "+ i);
				Thread.sleep(tempo);
			}
		}catch(InterruptedException e){
			e.printStackTrace();			
		}
		
		System.out.println("NOME FOI FINALIZADO!");
	}	

}
