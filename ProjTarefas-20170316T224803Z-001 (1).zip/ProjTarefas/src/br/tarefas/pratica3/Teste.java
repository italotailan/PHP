package br.tarefas.pratica3;


public class Teste {

	public static void main(String[] args) {
		MinhaTarefa tarefa1 = new MinhaTarefa("Tarefa #1",400);
	
		Thread t1= new Thread(tarefa1);
		t1.start();
	}

}
