package br.tarefas.pratica4;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Janela extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JButton btnTarefa1;
	private JButton btnTarefa2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Janela frame = new Janela();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Janela() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		this.contentPane = new JPanel();
		this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(this.contentPane);
		this.contentPane.setLayout(null);
		
		this.btnTarefa1 = new JButton("T1");
		this.btnTarefa1.addActionListener(this);
		this.btnTarefa1.setBounds(0, 0, 57, 23);
		this.contentPane.add(this.btnTarefa1);
		
		this.btnTarefa2 = new JButton("T2");
		this.btnTarefa2.addActionListener(this);
		this.btnTarefa2.setBounds(0, 34, 57, 23);
		this.contentPane.add(this.btnTarefa2);
	}
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == this.btnTarefa2) {
			btnTarefa2ActionPerformed(arg0);
		}
		if (arg0.getSource() == this.btnTarefa1) {
			btnTarefa1ActionPerformed(arg0);
		}
	}
	protected void btnTarefa1ActionPerformed(ActionEvent arg0) {
		MoverBotao btn1 = new MoverBotao(btnTarefa1,50);
		btn1.start();
		
	}
	protected void btnTarefa2ActionPerformed(ActionEvent arg0) {
		MoverBotao btn2 = new MoverBotao(btnTarefa2,10);
		btn2.start();
	}
}
