package br.tarefas.pratica4;

import javax.swing.JButton;

public class MoverBotao extends Thread{
	private JButton botao;
	private int tempo;
	
	public MoverBotao(JButton botao, int tempo){
		this.botao=botao;
		this.tempo=tempo;
	}
	
	
	public void run(){
		try{
			int x = botao.getBounds().x;
			for(int i = 1 ; i <= 200 ;i++){
				x = x + 1;
				botao.setBounds(x,
						botao.getBounds().y, 
						botao.getBounds().width,
						botao.getBounds().height);
			
			Thread.sleep(tempo);
			}
			
		}catch(InterruptedException e){
			e.printStackTrace();			
		}
	}

}
