package br.tarefas.pratica5;

import java.io.File;

import javax.swing.JOptionPane;

public class MonitoraDiretorio extends Thread {
	private String endereco;
	
	public MonitoraDiretorio(String endereco){
		this.endereco=endereco;
		this.start();
	}
	
	public void run(){
		File dir = new File(endereco);
		
		int num = 0 ;
		
		while(true){
			if(dir.listFiles().length != num){
				JOptionPane.showMessageDialog(null, "Qtd Arquivos : " + dir.listFiles().length );
			}
			num = dir.listFiles().length;
		}
	}
}
