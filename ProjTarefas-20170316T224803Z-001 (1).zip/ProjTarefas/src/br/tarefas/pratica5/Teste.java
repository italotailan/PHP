package br.tarefas.pratica5;

public class Teste {

	public static void main(String[] args) {
		
		String end= "C:\\Users\\logonucd.GRUPOCRUZEIRO\\Desktop\\dir1";
			MonitoraDiretorio t1 = new MonitoraDiretorio(end);
			//t1.start();
	}

}
